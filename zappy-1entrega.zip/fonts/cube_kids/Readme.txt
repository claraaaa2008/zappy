Hello,

Thank for downloading our font.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

This font is 100% FREE for COMMERCIAL USE.

Please visit our store for more amazing fonts : 
https://creatypestudio.co

Check our Font Bundle collection here:
https://creatypestudio.co/bundle

~~~ CANVA FONT BUNDLES ~~~
https://creatypestudio.co/canva-fonts

~~~ FUNNY FONT BUNDLES ~~~
https://creatypestudio.co/funny-fonts

~~~ CARNIVAL FONT BUNDLES ~~~
https://creatypestudio.co/carnival-fonts

~~~ COMIC FONT BUNDLES ~~~
https://creatypestudio.co/comic-fonts

~~~ MASCULINE FONT BUNDLES ~~~
https://creatypestudio.co/masculine-font

~~~ ROMANTIC FONT BUNDLES ~~~
https://creatypestudio.co/romatic-font

~~~ RETRO FONT BUNDLES ~~~
https://creatypestudio.co/retro-font

~~~ WEDDING FONT BUNDLES ~~~
https://creatypestudio.co/wedding-fonts

~~~ VINTAGE FONT BUNDLES ~~~
https://creatypestudio.co/vintage-fonts

-----------

Any donation are very appreciated. Paypal account for donation : https://paypal.me/CreatypeStudio
 


Follow our instagram for update : @creatypestudio

Thank you.