
This demo font is free for PERSONAL USE, but any donation are very appreciated

Here is the link to purchase commercial license:
https://ragamkatastudio.com/polhan-font/

For Corporate use you have to purchase Corporate license

If you need a custom license please contact us at
ragamkatastudio@gmail.com

Paypal donation :
https://www.paypal.com/paypalme/ragamkatastudio

Visit our store for more great fonts :
https://ragamkatastudio.com/

Thank you and Enjoy :)


-------------------------------------------


