var modal = document.getElementById("modal01");
function abrir() {
    //modal.style.display = "block";
    modal.style.display = "flex";
}
function volver() {
    modal.style.display = "none";
}