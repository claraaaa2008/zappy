Free for personal use only

Cutta Modern Sans Serif Fonts come in a variety of font styles, providing unlimited flexibility in expressing creativity. Ranging from sleeker and lighter styles to thicker and stronger styles, these fonts allow you to customize the appearance of your text according to your preferences and design needs.

Commercial license:
https://creativemarket.com/YUKITACREATIVE/26691544-Cutta-Sans-Serif

Buy a coffee:
https://paypal.me/yukitacreative